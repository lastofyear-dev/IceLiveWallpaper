package com.example.icelivewallpaper

import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class IceWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoWallpaperEngine()

    inner class VideoWallpaperEngine : Engine() {
        private var player: MediaPlayer? = null
        private var visible = false

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            startVideo(holder)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            player?.setSurface(holder.surface)
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            val p = player
            if (visibleNow) {
                if (p == null && surfaceHolder.surface.isValid) startVideo(surfaceHolder)
                else if (p != null) {
                    try { p.start() } catch (_: IllegalStateException) {}
                }
            } else {
                try { p?.pause() } catch (_: IllegalStateException) {}
            }
        }

        private fun startVideo(holder: SurfaceHolder) {
            releasePlayer()
            if (!holder.surface.isValid) return
            val mp = MediaPlayer()
            try {
                val afd = resources.openRawResourceFd(R.raw.mountain_lake)
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                mp.setSurface(holder.surface)
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                mp.setOnPreparedListener {
                    if (visible || isPreview) it.start()
                }
                mp.setOnErrorListener { mediaPlayer, _, _ ->
                    try { mediaPlayer.reset() } catch (_: Exception) {}
                    true
                }
                mp.prepareAsync()
                player = mp
            } catch (_: Exception) {
                try { mp.release() } catch (_: Exception) {}
                player = null
            }
        }

        private fun releasePlayer() {
            try {
                player?.setOnPreparedListener(null)
                player?.stop()
            } catch (_: Exception) {}
            try { player?.release() } catch (_: Exception) {}
            player = null
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            releasePlayer()
            super.onDestroy()
        }
    }
}
